export type Operation = "venta" | "alquiler";
export type PropertyType = "casa" | "departamento" | "terreno";
export type Tag = "nuevo" | "oportunidad" | "premium";

export type Property = {
  id: string;
  title: string;
  price: number;
  currency: "USD" | "ARS";
  operation: Operation;
  type: PropertyType;
  zone: string;
  rooms: number;
  area: number;
  image: string;
  tag?: Tag;
  description: string;
  features: string[];
};

export const properties: Property[] = [
  {
    id: "palermo-loft-245",
    title: "Loft luminoso con vista abierta",
    price: 245000,
    currency: "USD",
    operation: "venta",
    type: "departamento",
    zone: "Palermo",
    rooms: 3,
    area: 85,
    image:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuCY11fuBeoa26KjMkGzb_WATk_RWQyDuRcGHtkYtZrA-FvC0XTUNybg0Om-BU4foZPDeuDMeWL-kVeBaXwdI1DpOsFcBKnLbz0fRmbaysTkycW0GOCJbRj_btYaouBV_NB52cxAW6DJnyacIJ_rpa51280tNDNONsHmajsSTTqkpH30JlLZSYzbue3o74zHwLMuDgtA925fbIXZLXglKav6htVlIhurtpCe2kNTr0n_cBpV_rsrthsN",
    tag: "nuevo",
    description:
      "Departamento a estrenar en el corazón de Palermo, con ventanales de piso a techo, pisos de roble claro y living integrado. A pasos de plazas, restaurantes y transporte público.",
    features: ["Ventanales piso a techo", "Amenities: gimnasio y rooftop", "Cochera opcional", "Apto crédito"],
  },
  {
    id: "belgrano-casa-580",
    title: "Casa moderna con jardín",
    price: 580000,
    currency: "USD",
    operation: "venta",
    type: "casa",
    zone: "Belgrano",
    rooms: 5,
    area: 220,
    image:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuCvKi3qL6Ry4oNlKQ-6QUdBNs91YU1JY0HdpnGYwBzD0ibz5tNeBybJZloR-QcNKKTSaVhv7vJwevGIP4u4JRiPNebZ7qWRx3btOv2hHGtZsPy0--m9TWa9ZJXH-aNIcSEoUfr2eSouG3PoaejIZrci79UMgC2BmnAWJn79fl8HwKQTlvzxONRx_jeFctG5iphKv96Mw0Jqg2iRg7TyVPOrEiyDST6uopIl7ff4Vrt2A5kabtBPbY1d",
    description:
      "Casa de líneas geométricas limpias con amplios paneles vidriados y jardín delantero parquizado. Ideal para quienes buscan espacio, luz natural y privacidad en una de las zonas más cotizadas de la ciudad.",
    features: ["Jardín parquizado", "Quincho con parrilla", "5 ambientes", "Garage para 2 autos"],
  },
  {
    id: "nunez-depto-185",
    title: "Departamento con cocina de diseño",
    price: 185000,
    currency: "USD",
    operation: "venta",
    type: "departamento",
    zone: "Nuñez",
    rooms: 2,
    area: 55,
    image:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuDrXaHzuQYEAAEfnhl01p29qCi4-DhaXjoPA2lGCZHDBDHRW2TKHyBEWKwf99c31bTctqgSFXIV2b7iRkqekn-4UHcUj0oDbDfyLxxFkDYGSk2RXhrcWo8KcheMyGGbA63FHw2kx197upuSOfhUS7nmwqTHgVkeSEJbRuNg0pXojox3BklLtKw9JkeMZZdPr6n-8iS5RCDagUWAm1Rg4mOK9OhGLduZFVaGlKw0S5Mhm3RtZpG91ILa",
    description:
      "Unidad compacta y funcional en Nuñez, con cocina de diseño integrada, isla de mármol y detalles minimalistas. Excelente opción de inversión o primera vivienda.",
    features: ["Cocina con isla de mármol", "Balcón aterrazado", "Baulera incluida", "A 5 cuadras del tren"],
  },
  {
    id: "recoleta-suite-310",
    title: "Suite con balcón y vista a la ciudad",
    price: 310000,
    currency: "USD",
    operation: "venta",
    type: "departamento",
    zone: "Recoleta",
    rooms: 4,
    area: 120,
    image:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuDLGJCbGiXH4xh2jbDFNElPDcx_1YpcS0vu9X8368PDh5sehhFskU5NTxL8jnP_yZHQZ12SS5jOdXVQ9F9KrBBQJ_dL7l8kSskhKemweggmmj2qHmR8jHPKnVmVmS_fNZLnW2rqQ5u2WEQNRbzQiuDeerfXzB_QITx8Z8FEjYcxgyjqOppFt8ZxkTp-0plX_hrYmWfgDmA0UOq1F6IAhxw0Q0N2pbyBcleTr3GpmKJF4TDN5JD5IRrn",
    tag: "oportunidad",
    description:
      "Amplia suite en uno de los edificios más elegantes de Recoleta. Balcón privado con vista a la ciudad, luz natural durante todo el día y terminaciones de alta gama.",
    features: ["Balcón privado", "Vista panorámica", "Portero 24hs", "Edificio con lobby renovado"],
  },
  {
    id: "caballito-alquiler-2amb",
    title: "2 ambientes a estrenar",
    price: 480,
    currency: "USD",
    operation: "alquiler",
    type: "departamento",
    zone: "Caballito",
    rooms: 2,
    area: 48,
    image:
      "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=1200&q=80",
    tag: "nuevo",
    description:
      "Monoambiente dividido a estrenar, luminoso y con excelente distribución. Cocina separada, placares en dormitorio y balcón corrido.",
    features: ["A estrenar", "Balcón corrido", "Placares empotrados", "Cochera opcional"],
  },
  {
    id: "villa-urquiza-casa-alquiler",
    title: "Casa PH con patio propio",
    price: 950,
    currency: "USD",
    operation: "alquiler",
    type: "casa",
    zone: "Villa Urquiza",
    rooms: 3,
    area: 95,
    image:
      "https://images.unsplash.com/photo-1568605114967-8130f3a36994?auto=format&fit=crop&w=1200&q=80",
    description:
      "PH de dos plantas con patio propio, ideal para familias. Zona tranquila y arbolada, a metros del Parque Sarmiento.",
    features: ["Patio propio", "Dos plantas", "Living comedor integrado", "Apto mascotas"],
  },
  {
    id: "tigre-terreno",
    title: "Terreno frente al río",
    price: 130000,
    currency: "USD",
    operation: "venta",
    type: "terreno",
    zone: "Tigre",
    rooms: 0,
    area: 600,
    image:
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    tag: "premium",
    description:
      "Lote con frente al río, listo para construir. Zona residencial exclusiva con acceso a marina privada y espacios verdes comunes.",
    features: ["Frente al río", "600 m² totales", "Acceso a marina privada", "Zona residencial exclusiva"],
  },
  {
    id: "san-telmo-alquiler-loft",
    title: "Loft de estilo industrial",
    price: 620,
    currency: "USD",
    operation: "alquiler",
    type: "departamento",
    zone: "San Telmo",
    rooms: 2,
    area: 60,
    image:
      "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=1200&q=80",
    description:
      "Loft con techos altos, ladrillo a la vista y grandes ventanales en el barrio más histórico de la ciudad. Ideal para quienes buscan carácter y ubicación.",
    features: ["Techos altos", "Ladrillo a la vista", "Living con doble altura", "A metros de Plaza Dorrego"],
  },
];

export function formatPrice(property: Pick<Property, "price" | "currency" | "operation">) {
  const amount = new Intl.NumberFormat("es-AR").format(property.price);
  const suffix = property.operation === "alquiler" ? "/mes" : "";
  return `${property.currency} ${amount}${suffix}`;
}

export function getFeatured(count = 4) {
  return properties.slice(0, count);
}

export function getProperty(id: string) {
  return properties.find((p) => p.id === id);
}

export function filterProperties(params: {
  operation?: string;
  type?: string;
  zone?: string;
}) {
  return properties.filter((p) => {
    if (params.operation && p.operation !== params.operation) return false;
    if (params.type && p.type !== params.type) return false;
    if (params.zone && !p.zone.toLowerCase().includes(params.zone.toLowerCase())) return false;
    return true;
  });
}
